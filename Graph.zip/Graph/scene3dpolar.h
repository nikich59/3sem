#ifndef SCENE3DPOLAR_H
#define SCENE3DPOLAR_H

#include <scene3d.h>
#include <settingsdialogpolar.h>

class Scene3DPolar : public Scene3D
{
public:
    Scene3DPolar(QWidget *parent = nullptr);
    void setString(const QString &string) {function.setString(string); }
    void setVariableValue(const QString &name, double value) {
        function.setVariableValue(name, value); }
    void setDefault();
    QString getString() const;
    void drawLegend(QPainter &painter);
    SettingsPolar getSettings() const;
    QVector<double> axisXPoints() const;
    QVector<double> axisYPoints() const;

private:
    QFunction<double> function;
    QOperationCompiler<double> compiler;
    QString rName, phiName;
    uint netRMin, netPhi;
    QColor surfaceBottomColor;
    QColor surfaceMiddleColor;
    QColor surfaceTopColor;
    QVector<GLfloat> vertexInPolar;

    uint surfacePolygonNumber() const {return 0; }
    uint surfaceVertexNumber() const {return 0; }
    void updateTime();
    void updateSurface();
    void updateSurfaceBase();
    void updateNetBase();
    void updateNet();
    void runSettings();
    void runArguments();
    void drawCentralAxis();
    void drawBoundingAxis();
};

#endif // SCENE3DPOLAR_H
