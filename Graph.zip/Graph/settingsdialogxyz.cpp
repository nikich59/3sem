#include "settingsdialogxyz.h"
#include "ui_settingsdialogxyz.h"

SettingsDialogXYZ::SettingsDialogXYZ(SettingsXYZ sets, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SettingsDialogXYZ)
{
    ui->setupUi(this);

    commonSettingsWidget = new SettingsWidgetCommon(sets.common, this);
    commonSettingsWidget->setGeometry(0, 0, commonSettingsWidget->width(),
                                      commonSettingsWidget->height());
    this->setModal(true);
    ui->spinBox_centerX->setValue(sets.centerX);
    ui->spinBox_centerY->setValue(sets.centerY);
    ui->spinBox_centerZ->setValue(sets.centerZ);
    ui->checkBox_surfaceEnabled->setChecked(sets.isSurfaceEnable);
    ui->spinBox_netXMinNumber->setValue(sets.netXMin);
    ui->spinBox_netYMinNumber->setValue(sets.netYMin);
    ui->spinBox_rangeX->setValue(sets.rangeX);
    ui->spinBox_rangeY->setValue(sets.rangeY);
    ui->spinBox_rangeZ->setValue(sets.rangeZ);
    QPalette palette = ui->label_surfaceBottomColor->palette();
    palette.setColor(QPalette::Background, sets.surfaceBottomColor);
    ui->label_surfaceBottomColor->setPalette(palette);
    palette = ui->label_surfaceTopColor->palette();
    palette.setColor(QPalette::Background, sets.surfaceTopColor);
    ui->label_surfaceTopColor->setPalette(palette);
    palette = ui->label_surfaceMiddleColor->palette();
    palette.setColor(QPalette::Background, sets.surfaceMiddleColor);
    ui->label_surfaceMiddleColor->setPalette(palette);
    ui->lineEdit_nameX->setText(sets.xName);
    ui->lineEdit_nameY->setText(sets.yName);
}

SettingsDialogXYZ::~SettingsDialogXYZ()
{
    delete ui;
    delete commonSettingsWidget;
}

SettingsXYZ SettingsDialogXYZ::getSettings() const
{
    SettingsXYZ sets;
    sets.common = commonSettingsWidget->getSettings();
    sets.centerX = ui->spinBox_centerX->value();
    sets.centerY = ui->spinBox_centerY->value();
    sets.centerZ = ui->spinBox_centerZ->value();
    sets.isSurfaceEnable = ui->checkBox_surfaceEnabled->isChecked();
    sets.netXMin = ui->spinBox_netXMinNumber->value();
    sets.netYMin = ui->spinBox_netYMinNumber->value();
    sets.rangeX = ui->spinBox_rangeX->value();
    sets.rangeY = ui->spinBox_rangeY->value();
    sets.rangeZ = ui->spinBox_rangeZ->value();
    sets.surfaceBottomColor = ui->label_surfaceBottomColor->palette().background().color();
    sets.surfaceMiddleColor = ui->label_surfaceMiddleColor->palette().background().color();
    sets.surfaceTopColor = ui->label_surfaceTopColor->palette().background().color();
    sets.xName = ui->lineEdit_nameX->text();
    sets.yName = ui->lineEdit_nameY->text();
    return sets;
}

void SettingsDialogXYZ::on_pushButton_clicked()
{
    this->accept();
}

void SettingsDialogXYZ::on_pushButton_surfaceTopColor_clicked()
{
    QColorDialog colorDialog;
    QPalette palette = ui->label_surfaceTopColor->palette();
    palette.setColor(QPalette::Background, colorDialog.getColor(palette.background().color()));
    ui->label_surfaceTopColor->setPalette(palette);
}

void SettingsDialogXYZ::on_pushButton_surfaceMiddleColor_clicked()
{
    QColorDialog colorDialog;
    QPalette palette = ui->label_surfaceMiddleColor->palette();
    palette.setColor(QPalette::Background, colorDialog.getColor(palette.background().color()));
    ui->label_surfaceMiddleColor->setPalette(palette);
}

void SettingsDialogXYZ::on_pushButton_surfaceBottomColor_clicked()
{
    QColorDialog colorDialog;
    QPalette palette = ui->label_surfaceBottomColor->palette();
    palette.setColor(QPalette::Background, colorDialog.getColor(palette.background().color()));
    ui->label_surfaceBottomColor->setPalette(palette);
}

void SettingsDialogXYZ::on_pushButton_surfaceMiddleColorAuto_clicked()
{
    QPalette palette = ui->label_surfaceMiddleColor->palette();
    QColor topColor = ui->label_surfaceTopColor->palette().background().color();
    QColor bottomColor = ui->label_surfaceBottomColor->palette().background().color();
    palette.setColor(QPalette::Background, QColor((topColor.red() + bottomColor.red()) / 2,
                                                  (topColor.green() + bottomColor.green()) / 2,
                                                  (topColor.blue() + bottomColor.blue()) / 2));
    ui->label_surfaceMiddleColor->setPalette(palette);
}

void SettingsDialogXYZ::on_checkBox_surfaceEnabled_clicked()
{
    if (ui->checkBox_surfaceEnabled->isChecked()) {
        ui->pushButton_surfaceBottomColor->setEnabled(true);
        ui->pushButton_surfaceMiddleColor->setEnabled(true);
        ui->pushButton_surfaceTopColor->setEnabled(true);
        ui->pushButton_surfaceMiddleColorAuto->setEnabled(true);
    } else {
        ui->pushButton_surfaceBottomColor->setEnabled(false);
        ui->pushButton_surfaceMiddleColor->setEnabled(false);
        ui->pushButton_surfaceTopColor->setEnabled(false);
        ui->pushButton_surfaceMiddleColorAuto->setEnabled(false);
    }
}
