#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    Complex c(0, -1);
    Complex z = Complex(log(c.re() * c.re() + c.im() * c.im()) / 2.0, atan2(c.im(), c.re()));
    int u = 9;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    Scene3DXYZ *scene = new Scene3DXYZ();
    scene->setGeometry(200, 200, 640, 480);
    scene->show();
}

void MainWindow::on_pushButton_2_clicked()
{
    Scene3DComplex *scene = new Scene3DComplex();
    scene->setGeometry(200, 200, 640, 480);
    scene->show();
}

void MainWindow::on_pushButton_3_clicked()
{
    Scene3DPolar *scene = new Scene3DPolar();
    scene->setGeometry(200, 200, 640, 480);
    scene->show();
}
