#ifndef SCENE3DWIDGET_H
#define SCENE3DWIDGET_H

#include <QGLWidget>

class Scene3DWidget : public QGLWidget
{
public:
    Scene3DWidget();
};

#endif // SCENE3DWIDGET_H
