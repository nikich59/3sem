#include "scene3d.h"

Scene3D::Scene3D(QWidget *parent) : QGLWidget(parent)
{
    setAutoFillBackground(false);

    isolineMin = 8;
    scaleRate = 1.1;
    setMouseTracking(true);
    setMoveButton(Qt::LeftButton);
    isActivatedTime = false;
    timeName = QString("t");
    timeStep = 0.050;
    timerId = -1;
    verticalExtension = 1.0;
    isShowedLegend = true;
    legendSizeRatio = 0.5;
    legendBackOpacity = 0.5;
    isNativeProportions = true;
    isPerspectiveEnabled = true;
    xPolygonNum = 1;
    yPolygonNum = 1;
}

Scene3D::~Scene3D()
{
}

void Scene3D::startSelfUpdating(double timeStep)
{
    if (timerId != -1)
        killTimer(timerId);
    this->timeStep = timeStep;
    timerId = this->startTimer((int)round((double)timeStep * 1000.0));
    isActivatedTime = true;
}

SettingsCommon Scene3D::getCommonSettings() const
{
    SettingsCommon sets;
    sets.funcString = this->getString();
    sets.axis = axis;
    sets.axis1Color = axis1Color;
    sets.axis2Color = axis2Color;
    sets.axis3Color = axis3Color;
    sets.contextFileName = contextFileName;
    sets.isActivatedTime = isActivatedTime;
    sets.isIsonetEnable = isIsonetEnable;
    sets.isNetEnable = isNetEnable;
    sets.isolineMin = isolineMin;
    sets.isonetColor = isonetColor;
    sets.isonetWidth = isonetWidth;
    sets.netColor = netColor;
    sets.netWidth = netWidth;
    sets.radius = radius;
    sets.scaleRate = scaleRate;
    sets.sceneMoveMouseButton = sceneMoveMouseButton;
    sets.time = startTime.msecsTo(QTime::currentTime());
    sets.timeStep = timeStep;
    sets.timeName = timeName;
    sets.xPolygonNum = xPolygonNum;
    sets.yPolygonNum = yPolygonNum;
    sets.verticalExtension = verticalExtension;
    sets.isShowedLegend = isShowedLegend;
    sets.legendSizeRatio = legendSizeRatio;
    sets.legendBackOpacity = legendBackOpacity;
    sets.isPerspectiveEnabled = isPerspectiveEnabled;
    sets.isNativeProportions = isNativeProportions;
    return sets;
}

void Scene3D::setCommonSettings(const SettingsCommon &sets)
{
    this->setString(sets.funcString);
    axis = sets.axis;
    axis1Color = sets.axis1Color;
    axis2Color = sets.axis2Color;
    axis3Color = sets.axis3Color;
    contextFileName = sets.contextFileName;
    isActivatedTime = sets.isActivatedTime;
    timeStep = sets.timeStep;
    if (isActivatedTime)
        startSelfUpdating(timeStep);
    else
        stopSelfUpdating();
    isIsonetEnable = sets.isIsonetEnable;
    isNetEnable = sets.isNetEnable;
    netColor = sets.netColor;
    netWidth = sets.netWidth;
    isolineMin = sets.isolineMin;
    isonetColor = sets.isonetColor;
    isonetWidth = sets.isonetWidth;
    radius = sets.radius;
    scaleRate = sets.scaleRate;
    sceneMoveMouseButton = sets.sceneMoveMouseButton;
    startTime = QTime::currentTime();
    startTime.addMSecs(sets.time);
    timeName = sets.timeName;
    xPolygonNum = sets.xPolygonNum;
    yPolygonNum = sets.yPolygonNum;
    verticalExtension = sets.verticalExtension;
    isShowedLegend = sets.isShowedLegend;
    legendSizeRatio = sets.legendSizeRatio;
    legendBackOpacity = sets.legendBackOpacity;
    isPerspectiveEnabled = sets.isPerspectiveEnabled;
    isNativeProportions = sets.isNativeProportions;
    updateBase();
    /*update();*/
    repaint();
}

void Scene3D::draw()
{
    if (isSurfaceEnable) {
        drawSurface();
    }
    if (isNetEnable) {
        drawNet();
    }
    if (isIsonetEnable) {
        drawIsonet();
    }
    drawAxis();
}

void Scene3D::update()
{
    updateTime();
    if (isSurfaceEnable || isIsonetEnable) {
        updateSurface();
    }
    if (isNetEnable) {
        updateNet();
    }
    if (isIsonetEnable) {
        updateIsoline();
    }
}

void Scene3D::updateBase()
{
    updateSurfaceBase();
    updateNetBase();
    update();
}

void Scene3D::timerEvent(QTimerEvent *)
{
    update();
    repaint();
}

void Scene3D::wheelEvent(QWheelEvent *event)
{
    if (event->buttons() == Qt::NoButton) {
        double k = event->delta() > 0 ? 1.0 / scaleRate : scaleRate;
        setRange(rangeX *k, rangeY * k, rangeZ * k);
        repaint();
    }
    if (event->buttons() == Qt::LeftButton) {
        setRadius(radius * (event->delta() > 0 ? 0.95 : 1.05));
        repaint();
    }
}

void Scene3D::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() == Qt::NoButton)
        this->setCursor(Qt::ArrowCursor);
    else if (event->buttons() == sceneMoveMouseButton)
        this->setCursor(Qt::ClosedHandCursor);
    else this->setCursor(Qt::ArrowCursor);

    if (event->buttons() == sceneMoveMouseButton) {
        setRot(xRot - M_PI * (float)(event->pos() - lastCursorPos).y() / this->height(),
               yRot,
               zRot + 2.0 * M_PI * (float)(event->pos() - lastCursorPos).x() / this->width());
        lastCursorPos = event->pos();
        repaint();
    }
}

void Scene3D::mousePressEvent(QMouseEvent *event)
{
    lastCursorPos = event->pos();
}

void Scene3D::mouseReleaseEvent(QMouseEvent *event)
{

}

void Scene3D::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Up: setCenter(centerX + rangeX / 10.0, centerY, centerZ); break;
    case Qt::Key_Down: setCenter(centerX - rangeX / 10.0, centerY, centerZ); break;
    case Qt::Key_Left: setCenter(centerX, centerY + rangeY / 10.0, centerZ); break;
    case Qt::Key_Right: setCenter(centerX, centerY - rangeY / 10.0, centerZ); break;
    case Qt::Key_Plus: setCenter(centerX, centerY, centerZ + rangeZ / 10.0); break;
    case Qt::Key_Minus: setCenter(centerX, centerY, centerZ - rangeZ / 10.0); break;
    case Qt::Key_S: runSettings(); break;
    case Qt::Key_A: runArguments(); break;
    }
}

void Scene3D::paintEvent(QPaintEvent *)
{
    const double closest = 0.003;
    makeCurrent();
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    qglClearColor(Qt::white);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_POINT_SMOOTH);
    glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glViewport(0, 0, width(), height());

    GLfloat whratio;
    if (isNativeProportions)
        whratio = (GLfloat) this->width() / (GLfloat) this->height();
    else
        whratio = 1.0;
    if (isPerspectiveEnabled)
        glFrustum(-closest * whratio, closest * whratio, -closest, closest, closest, 10.0);
    else
        glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    if (isPerspectiveEnabled) {
        glTranslatef(0.0, 0.0, -radius);
        glRotatef(-90.0 - xRot * 180.0 / M_PI, 1.0f, 0.0f, 0.0f);
        glRotatef(yRot * 180.0 / M_PI, 0.0f, 1.0f, 0.0f);
        glRotatef(zRot * 180.0 / M_PI, 0.0f, 0.0f, 1.0f);
        glRotatef(-xLookAroundRot * 180.0 / M_PI, 1.0f, 0.0f, 0.0f);
        glRotatef(zLookAroundRot * 180.0 / M_PI, 0.0f, 0.0f, 1.0f);
        glScalef(1.0 / rangeX, 1.0 / rangeY, 1.0 / rangeZ * verticalExtension);
        glTranslatef(-centerX, -centerY, -centerZ);
    } else {
        glScalef(2.0 / whratio / radius, 2.0 / radius, radius);
        glRotatef(-90.0 - xRot * 180.0 / M_PI, 1.0f, 0.0f, 0.0f);
        glRotatef(yRot * 180.0 / M_PI, 0.0f, 1.0f, 0.0f);
        glRotatef(zRot * 180.0 / M_PI, 0.0f, 0.0f, 1.0f);
        glRotatef(-xLookAroundRot * 180.0 / M_PI, 1.0f, 0.0f, 0.0f);
        glRotatef(zLookAroundRot * 180.0 / M_PI, 0.0f, 0.0f, 1.0f);
        glScalef(1.0 / rangeX / radius, 1.0 / rangeY / radius, 1.0 / rangeZ *
                 verticalExtension / radius);
        glTranslatef(-centerX, -centerY, -centerZ);
    }

    draw();

    glShadeModel(GL_FLAT);
    glDisable(GL_CULL_FACE);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();

    QPainter painter;
    painter.begin(this);
    if (isShowedLegend) {
        drawLegend(painter);
    }
    painter.end();
}

void Scene3D::closeEvent(QCloseEvent *event)
{
    delete this;
}

void Scene3D::initializeGL()
{
    qglClearColor(Qt::white);
    glEnable(GL_DEPTH_TEST);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_POINT_SMOOTH);
    glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
}

void Scene3D::resizeGL(int w, int h)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
}


void Scene3D::drawSurface() const
{
    glEnableClientState(GL_COLOR_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, surfaceVertex.data());
    glColorPointer(4, GL_FLOAT, 0, surfaceColor.data());
    glDrawElements(GL_QUADS, surfaceIndex.length(), GL_UNSIGNED_INT, surfaceIndex.data());
}

void Scene3D::drawNet() const
{
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, netVertex.data());
    glDisableClientState(GL_COLOR_ARRAY);
    glColor3f(netColor.redF(), netColor.greenF(), netColor.blueF());
    glLineWidth(netWidth);
    glDrawElements(GL_LINES, netIndex.length(), GL_UNSIGNED_INT, netIndex.data());
}

void Scene3D::updateSurfaceBase()
{
    surfaceColor.resize(surfaceVertexNumber() * 4);
    surfaceIndex.resize(surfacePolygonNumber() * 4);
    surfaceVertex.resize(surfaceVertexNumber() * 3);

    GLfloat *surfaceVertex = this->surfaceVertex.data();
    GLuint *surfaceIndex = this->surfaceIndex.data();
    GLfloat *surfaceColor = this->surfaceColor.data();

    for (int x = 0; x <= xPolygonNum; x++)
        for (int y = 0; y <= yPolygonNum; y++) {
            surfaceVertex[3 * (x * (yPolygonNum + 1) + y) + 0] = centerX - rangeX / 2.0 +
                    (GLfloat) x * rangeX / (xPolygonNum/* + 1*/); // X
            surfaceVertex[3 * (x * (yPolygonNum + 1) + y) + 1] = centerY - rangeY / 2.0 +
                    (GLfloat) y * rangeY / (yPolygonNum/* + 1*/); // Y
        }
    for (int x = 0; x < xPolygonNum; x++)
        for (int y = 0; y < yPolygonNum; y++) {
            surfaceIndex[4 * (x * yPolygonNum + y) + 0] = x * (yPolygonNum + 1) + y;
            surfaceIndex[4 * (x * yPolygonNum + y) + 1] = x * (yPolygonNum + 1) + y + 1;
            surfaceIndex[4 * (x * yPolygonNum + y) + 2] = (x + 1) * (yPolygonNum + 1) + y + 1;
            surfaceIndex[4 * (x * yPolygonNum + y) + 3] = (x + 1) * (yPolygonNum + 1) + y;
        }

    int length = this->surfaceColor.length() / 4;
    for (int i = 0; i < length; i++) {
        surfaceColor[i * 4 + 0] = 0.5;
        surfaceColor[i * 4 + 1] = 0.5;
        surfaceColor[i * 4 + 2] = 0.5;
        surfaceColor[i * 4 + 3] = 1.0;
    }
}

void Scene3D::updateIsoline()
{
#define err 0.0
    isolineIndex.clear();
    isolineVertex.clear();
    GLfloat p1x, p1y, p1z;
    GLfloat p2x, p2y, p2z;
    GLfloat p3x, p3y, p3z;
    GLfloat p4x, p4y, p4z;
    if (rangeZ < 1e-127)
        return;
    QVector<double> points = axisZPoints();
    double step = points.length() > 1 ? points[1] - points[0] : 0.0;
    int min = round(points.first() / step) - round(rangeZ / 2.0 / step);
    int max = round(points.last() / step) + round(rangeZ / 2.0 / step);
    int isolineNum1, isolineNum2, isolineNum3;
    int isolineNumMin, isolineNumMax;
    GLfloat pointX, pointY, pointZ;
    int length = surfaceIndex.length() / 4;

    GLfloat *surfaceVertex = this->surfaceVertex.data();
    GLuint *surfaceIndex = this->surfaceIndex.data();
    for (int i = 0; i < length; i++) {
        p1x = surfaceVertex[3 * surfaceIndex[4 * i]];
        p1y = surfaceVertex[3 * surfaceIndex[4 * i] + 1];
        p1z = surfaceVertex[3 * surfaceIndex[4 * i] + 2];
        p2x = surfaceVertex[3 * surfaceIndex[4 * i + 1]];
        p2y = surfaceVertex[3 * surfaceIndex[4 * i + 1] + 1];
        p2z = surfaceVertex[3 * surfaceIndex[4 * i + 1] + 2];
        p3x = surfaceVertex[3 * surfaceIndex[4 * i + 2]];
        p3y = surfaceVertex[3 * surfaceIndex[4 * i + 2] + 1];
        p3z = surfaceVertex[3 * surfaceIndex[4 * i + 2] + 2];
        p4x = surfaceVertex[3 * surfaceIndex[4 * i + 3]];
        p4y = surfaceVertex[3 * surfaceIndex[4 * i + 3] + 1];
        p4z = surfaceVertex[3 * surfaceIndex[4 * i + 3] + 2];
        isolineNum1 = round(p1z / step - 0.5);
        isolineNum2 = round(p2z / step - 0.5);
        isolineNum3 = round(p3z / step - 0.5);
        ///////////////////////
        /*if (fabs(p2z / step - round(p2z / step)) < 1e-6 &&
            fabs(p4z / step - round(p4z / step)) < 1e-6 &&
            fabs(p1z / step - round(p1z / step)) > 1e-6) {
            isolineVertex.push_back(p2x);
            isolineVertex.push_back(p2y);
            isolineVertex.push_back(p2z);
            isolineVertex.push_back(p4x);
            isolineVertex.push_back(p4y);
            isolineVertex.push_back(p4z);
            isolineIndex.push_back(isolineVertex.length() / 3 - 2);
            isolineIndex.push_back(isolineVertex.length() / 3 - 1);
        }*/
        ///////////////////////
        if (isolineNum1 != isolineNum2 || isolineNum2 != isolineNum3) {
            isolineNumMin = std::min(isolineNum1, std::min(isolineNum2, isolineNum3));
            isolineNumMax = std::max(isolineNum1, std::max(isolineNum2, isolineNum3));
            if (isolineNumMin > max)
                continue;
            if (isolineNumMax < min)
                continue;
            if (isolineNumMin < min)
                isolineNumMin = min;
            if (isolineNumMax > max)
                isolineNumMax = max;
            for (int i = isolineNumMin; i <= isolineNumMax; i++) {
                pointZ = (double)i * step;
                if ((pointZ - p1z) * (p2z - pointZ) >= err) {
                    if ((pointZ - p2z) * (p3z - pointZ) >= err) {
                        pointX = (pointZ - p1z) / (p2z - p1z) * (p2x - p1x) + p1x;
                        pointY = (pointZ - p1z) / (p2z - p1z) * (p2y - p1y) + p1y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        pointX = (pointZ - p2z) / (p3z - p2z) * (p3x - p2x) + p2x;
                        pointY = (pointZ - p2z) / (p3z - p2z) * (p3y - p2y) + p2y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 2);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 1);
                    } else if ((pointZ - p1z) * (p3z - pointZ) >= 0.0) {
                        pointX = (pointZ - p1z) / (p2z - p1z) * (p2x - p1x) + p1x;
                        pointY = (pointZ - p1z) / (p2z - p1z) * (p2y - p1y) + p1y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        pointX = (pointZ - p1z) / (p3z - p1z) * (p3x - p1x) + p1x;
                        pointY = (pointZ - p1z) / (p3z - p1z) * (p3y - p1y) + p1y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 2);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 1);
                    }
                } else if ((pointZ - p2z) * (p3z - pointZ) >= err) {
                    if ((pointZ - p1z) * (p3z - pointZ) >= err) {
                        pointX = (pointZ - p3z) / (p2z - p3z) * (p2x - p3x) + p3x;
                        pointY = (pointZ - p3z) / (p2z - p3z) * (p2y - p3y) + p3y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        pointX = (pointZ - p1z) / (p3z - p1z) * (p3x - p1x) + p1x;
                        pointY = (pointZ - p1z) / (p3z - p1z) * (p3y - p1y) + p1y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 2);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 1);
                    }
                }
            }
        }
        p2x = p4x;
        p2y = p4y;
        p2z = p4z;
        isolineNum2 = round(p2z / step - 0.5);
        if (!(isolineNum1 == isolineNum2 && isolineNum2 == isolineNum3)) {
            isolineNumMin = std::min(isolineNum1, std::min(isolineNum2, isolineNum3));
            isolineNumMax = std::max(isolineNum1, std::max(isolineNum2, isolineNum3));
            if (isolineNumMin > max)
                continue;
            if (isolineNumMax < min)
                continue;
            if (isolineNumMin < min)
                isolineNumMin = min;
            if (isolineNumMax > max)
                isolineNumMax = max;
            for (int i = isolineNumMin; i <= isolineNumMax; i++) {
                pointZ = (GLfloat)i * step;
                if ((pointZ - p1z) * (p2z - pointZ) >= err) {
                    if ((pointZ - p2z) * (p3z - pointZ) >= err) {
                        pointX = (pointZ - p1z) / (p2z - p1z) * (p2x - p1x) + p1x;
                        pointY = (pointZ - p1z) / (p2z - p1z) * (p2y - p1y) + p1y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        pointX = (pointZ - p2z) / (p3z - p2z) * (p3x - p2x) + p2x;
                        pointY = (pointZ - p2z) / (p3z - p2z) * (p3y - p2y) + p2y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 2);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 1);
                    } else if ((pointZ - p1z) * (p3z - pointZ) >= 0.0) {
                        pointX = (pointZ - p1z) / (p2z - p1z) * (p2x - p1x) + p1x;
                        pointY = (pointZ - p1z) / (p2z - p1z) * (p2y - p1y) + p1y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        pointX = (pointZ - p1z) / (p3z - p1z) * (p3x - p1x) + p1x;
                        pointY = (pointZ - p1z) / (p3z - p1z) * (p3y - p1y) + p1y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 2);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 1);
                    }
                } else if ((pointZ - p2z) * (p3z - pointZ) >= err) {
                    if ((pointZ - p1z) * (p3z - pointZ) >= err) {
                        pointX = (pointZ - p3z) / (p2z - p3z) * (p2x - p3x) + p3x;
                        pointY = (pointZ - p3z) / (p2z - p3z) * (p2y - p3y) + p3y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        pointX = (pointZ - p1z) / (p3z - p1z) * (p3x - p1x) + p1x;
                        pointY = (pointZ - p1z) / (p3z - p1z) * (p3y - p1y) + p1y;
                        isolineVertex.push_back(pointX);
                        isolineVertex.push_back(pointY);
                        isolineVertex.push_back(pointZ);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 2);
                        isolineIndex.push_back(isolineVertex.length() / 3 - 1);
                    }
                }
            }
        }
    }
}

void Scene3D::drawIsonet()
{
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, isolineVertex.data());
    glDisableClientState(GL_COLOR_ARRAY);
    glColor3f(isonetColor.redF(), isonetColor.greenF(), isonetColor.blueF());
    glLineWidth(isonetWidth);
    glDrawElements(GL_LINES, isolineIndex.length(), GL_UNSIGNED_INT, isolineIndex.data());
}

void Scene3D::drawAxis()
{
    if (axis == CENTRAL_AXIS)
        drawCentralAxis();
    else if (axis == BOUNDING_AXIS || axis == BOUNDING_AXIS_CELLULAR)
        drawBoundingAxis();
}

QVector<double> Scene3D::axisZPoints() const
{
    return axisPoints(centerZ, rangeZ, isolineMin);
}

QVector<double> Scene3D::axisXBasePoints(uint num) const
{
    QVector<double> points = axisXPoints();
    QVector<double> base;
    for (int i = 0; i < points.length(); i++) {
        if (i % (points.length() / num) == 0) {
            base.push_back(points[i]);
        }
    }
    return base;
}

QVector<double> Scene3D::axisYBasePoints(uint num) const
{
    QVector<double> points = axisYPoints();
    QVector<double> base;
    for (int i = 0; i < points.length(); i++) {
        if (i % (points.length() / num) == 0) {
            base.push_back(points[i]);
        }
    }
    return base;
}

QVector<double> Scene3D::axisZBasePoints(uint num) const
{
    QVector<double> points = axisZPoints();
    QVector<double> base;
    for (int i = 0; i < points.length(); i++) {
        if (i % (points.length() / num) == 0) {
            base.push_back(points[i]);
        }
    }
    return base;
}

QVector<double> Scene3D::axisPoints(double center, double range, int minNum) const
{
    if (range < 1e-125)
        return QVector<double>();
    double step = pow(10.0, ceil(log(range / minNum) / log(10.0)));
    if (range / step < minNum)
        step /= 2.0;
    if (range / step < minNum)
        step /= 2.5;
    if (range / step < minNum)
        step /= 2.0;
    double min = step * round((center - range / 2.0) / step + 0.5);
    double max = step * (round((center + range / 2.0) / step - 0.5) + 0.5);
    QVector<double> v;
    for (double i = min; i <= max; i += step)
        v.push_back(i);
    return v;
}

void Scene3D::drawCentralAxis()
{
    glLineWidth(2.0);
    glDisable(GL_DEPTH_TEST);
    GLfloat X[] = {centerX, centerY, centerZ, centerX + rangeX * axisLengthRatio, centerY, centerZ};
    GLfloat Y[] = {centerX, centerY, centerZ, centerX, centerY + rangeY * axisLengthRatio, centerZ};
    GLfloat Z[] = {centerX, centerY, centerZ, centerX, centerY, centerZ + rangeZ * axisLengthRatio /
                  verticalExtension};
    GLuint i[2] = {0, 1};
    glDisableClientState(GL_COLOR_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, X);
    glColor3f(axis1Color.redF(), axis1Color.greenF(), axis1Color.blueF());
    glDrawElements(GL_LINES, 2, GL_UNSIGNED_INT, i);
    glVertexPointer(3, GL_FLOAT, 0, Y);
    glColor3f(axis2Color.redF(), axis2Color.greenF(), axis2Color.blueF());
    glDrawElements(GL_LINES, 2, GL_UNSIGNED_INT, i);
    glVertexPointer(3, GL_FLOAT, 0, Z);
    glColor3f(axis3Color.redF(), axis3Color.greenF(), axis3Color.blueF());
    glDrawElements(GL_LINES, 2, GL_UNSIGNED_INT, i);
    glEnable(GL_DEPTH_TEST);
}

void PaintThread::run()
{
    painter->drawLine(0, 0, 100, 100);
}
