#ifndef SCENE3D_H
#define SCENE3D_H

#include <QGLWidget>
#include <QWheelEvent>
#include <qgl.h>
#include <qoperation.h>
#include <mathexpression.h>
#include <QLabel>
#include <GL/gl.h>
#include <QtOpenGL>
#include <stdlib.h>
#include <settingswidgetcommon.h>
#include <argumentsdialog.h>

class Scene3D : public QGLWidget
{
public:
    Scene3D(QWidget *parent = nullptr);
    virtual ~Scene3D();
    virtual void setString(const QString &string) = 0;
    virtual QString getString() const = 0;
    void setCenter(double x, double y, double z) {centerX = x; centerY = y; centerZ = z;
                                                  updateBase(); }
    void setRange(double xr, double yr, double zr) {rangeX = xr, rangeY = yr; rangeZ = zr;
                                                   updateBase(); }
    double RangeX() const {return rangeX; }
    double RangeY() const {return rangeY; }
    double RangeZ() const {return rangeZ; }
    void setPolygonRange(uint polygonXRange, uint polygonYRange) {xPolygonNum = polygonXRange;
                                                                  yPolygonNum = polygonYRange;
                                                                  updateBase(); }
    void zoomIn(float value) {rangeX /= value; rangeY /= value; rangeZ /= value; update(); }
    void zoomOut(float value) {rangeX *= value; rangeY *= value; rangeZ *= value; update(); }
    void setAxis(uint axis) {this->axis = axis; }
    uint Axis() const {return axis; }
    void setAxisColor(QColor axis1Color, QColor axis2Color, QColor axis3Color) {
        this->axis1Color = axis1Color; this->axis2Color = axis2Color; this->axis3Color = axis3Color; }
    void setAxisLengthRatio(GLfloat ratio) {axisLengthRatio = ratio; }
    void setNetEnable(bool enableNet) {isNetEnable = enableNet; }
    void setNetWidth(float netWidth) {this->netWidth = netWidth; }
    void setNetColor(QColor netColor) {this->netColor = netColor; }
    void setIsonetEnable(bool enableIsonet) {isIsonetEnable = enableIsonet; }
    void setIsonetColor(QColor isonetColor) {this->isonetColor = isonetColor; }
    void setIsonetWidth(GLfloat width) {isonetWidth = width; }
    bool setSurfaceEnable(bool enableSurface) {isSurfaceEnable = enableSurface; }
    virtual void setVariableValue(const QString &name, double value) = 0;
    void setTimeName(const QString &timeName) {this->timeName = timeName; }
    void setRadius(float radius) {this->radius = radius; }
    void setRot(float rotX, float rotY, float rotZ) {xRot = rotX; yRot = rotY; zRot = rotZ; }
    float RotX() const {return xRot; }
    float RotY() const {return yRot; }
    float RotZ() const {return zRot; }

    void setContextFileName(const QString &fileName) {contextFileName = fileName; }

    void setScaleRate(double rate) {if (rate > 0.0) scaleRate = rate; }
    void setMoveButton(int button) {sceneMoveMouseButton = button; }

    void activateTime(bool timeActivated) {isActivatedTime = timeActivated;
                                           startTime = QTime::currentTime(); }

    void startSelfUpdating(double timeStep);
    void stopSelfUpdating() {this->killTimer(timerId); isActivatedTime = false; timerId = -1;}

    SettingsCommon getCommonSettings() const;
    void setCommonSettings(const SettingsCommon &sets);

    virtual void setDefault() = 0;
    void draw();
    void update();
    void updateBase();

    virtual void timerEvent(QTimerEvent *);
    virtual void drawLegend(QPainter &painter) = 0;

public slots:
    virtual void wheelEvent(QWheelEvent *);
    virtual void mouseMoveEvent(QMouseEvent *);
    virtual void mousePressEvent(QMouseEvent *);
    virtual void mouseReleaseEvent(QMouseEvent *);
    virtual void keyPressEvent(QKeyEvent *);
    void paintEvent(QPaintEvent *);
    void closeEvent(QCloseEvent *);

protected:
    void initializeGL();
    void resizeGL(int w, int h);
    virtual void updateTime() = 0;
    virtual void runSettings() = 0;
    virtual void runArguments() = 0;

    int timerId;

    uint axis;
    QColor axis1Color, axis2Color, axis3Color;
    GLfloat axisLengthRatio;
    bool isNetEnable;
    float netWidth;
    QColor netColor;
    bool isIsonetEnable;
    QColor isonetColor;
    bool isSurfaceEnable;

    double centerX, centerY, centerZ;
    double rangeX, rangeY, rangeZ;
    double verticalExtension;

    float xRot, yRot, zRot;
    float xLookAroundRot, yLookAroundRot, zLookAroundRot;
    float radius;

    uint xPolygonNum, yPolygonNum;

    QVector<GLfloat> surfaceVertex;
    QVector<GLuint> surfaceIndex;
    QVector<GLfloat> surfaceColor;
    virtual uint surfaceVertexNumber() const {return (xPolygonNum + 1) * (yPolygonNum + 1); }
    virtual uint surfacePolygonNumber() const {return xPolygonNum * yPolygonNum; }

    QVector<GLfloat> netVertex;
    QVector<GLuint> netIndex;
    /*uint netVertexNumber;
    uint netLineNumber;*/
    GLfloat isonetWidth;

    uint isolineMin;
    QVector<GLfloat> isolineVertex;
    QVector<GLuint> isolineIndex;

    bool isActivatedTime;
    QString timeName;
    QTime startTime;
    double timeStep;

    QString contextFileName;

    double scaleRate; // if > 1 then straight scaling otherwise it`s inversed

    QPoint lastCursorPos;

    int sceneMoveMouseButton;

    bool isShowedLegend;
    double legendSizeRatio;
    float legendBackOpacity;

    bool isNativeProportions;

    bool isPerspectiveEnabled;

    virtual void drawSurface() const;
    virtual void drawNet() const;
    virtual void updateSurfaceBase();
    virtual void updateSurface() = 0;
    virtual void updateNetBase() = 0;
    virtual void updateNet() = 0;
    virtual void updateIsoline();
    virtual void drawIsonet();
    virtual void drawCentralAxis();
    virtual void drawBoundingAxis() = 0;
    virtual void drawAxis();
    virtual QVector<double> axisPoints(double center, double range, int minNum) const;
    virtual QVector<double> axisXPoints() const = 0;
    virtual QVector<double> axisYPoints() const = 0;
    virtual QVector<double> axisZPoints() const;
    virtual QVector<double> axisXBasePoints(uint num) const;
    virtual QVector<double> axisYBasePoints(uint num) const;
    virtual QVector<double> axisZBasePoints(uint num) const;

public:
    static const uint NO_AXIS = 0b1;
    static const uint CENTRAL_AXIS = 0b10;
    static const uint BOUNDING_AXIS = 0b100;
    static const uint BOUNDING_AXIS_CELLULAR = 0b1000;
};

class PaintThread : public QThread
{
public:
    PaintThread(QPainter *painter, QObject *parent = 0x0) : painter(painter), QThread(parent) {}
    void run();
private:
    QPainter *painter;
};

#endif // SCENE3D_H
